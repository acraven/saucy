﻿namespace Saucy.Example.ProjectA
{
    public class Status
    {
        public string Ping()
        {
            return "Pong!";
        }
    }
}
