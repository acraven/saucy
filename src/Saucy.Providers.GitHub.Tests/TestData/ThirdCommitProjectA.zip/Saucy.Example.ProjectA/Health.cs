﻿namespace Saucy.Example.ProjectA
{
   public class Health
   {
      public string Ping()
      {
         return "PONG!";
      }
   }
}
